import type { SlotTimeline } from '../api/client';

export interface TimelineLaneStats {
  activeCount: number;
  historicalCount: number;
  rejectedCount: number;
  totalCount: number;
}

/**
 * Generate a unique, deterministic key for a slot timeline lane.
 */
export function getTimelineLaneKey(lane: SlotTimeline): string {
  return `${lane.entity}-${lane.attribute}-${lane.context_key || ''}`;
}

/**
 * Compute summary statistics for a slot timeline lane.
 */
export function getTimelineLaneStats(lane: SlotTimeline): TimelineLaneStats {
  const memories = lane.memories ?? [];
  const rejected = lane.rejected ?? [];

  const activeCount = memories.filter(
    (m) => m.memory.status === 'active'
  ).length;
  const historicalCount = memories.filter(
    (m) => m.memory.status !== 'active'
  ).length;
  const rejectedCount = rejected.length;

  return {
    activeCount,
    historicalCount,
    rejectedCount,
    totalCount: memories.length + rejectedCount,
  };
}
