# Location: src/memorymesh/models.py (Lines 692-720, 767-775)
class GraphNode(MeshBaseModel):
    """Node in the memory/entity dependency and relationship graph."""

    id: str
    kind: Literal["entity", "memory"]
    label: str
    status: MemoryStatus | None = None
    confidence: float | None = None
    needs_review: bool = False
    meta: dict[str, Any] = Field(default_factory=dict)


class GraphEdge(MeshBaseModel):
    """Directed edge in the memory/entity graph."""

    id: str
    source: str
    target: str
    type: Literal["about", "supersedes", "refines", "contradicts", "depends_on"]
    reason: str = ""


class GraphResponse(MeshBaseModel):
    """Complete graph response containing nodes and edges."""

    nodes: list[GraphNode] = Field(default_factory=list)
    edges: list[GraphEdge] = Field(default_factory=list)



class SlotTimeline(MeshBaseModel):
    """Timeline lane for a specific entity attribute and context."""

    entity: str
    attribute: str
    context_key: str = ""
    memories: list[MemoryView] = Field(default_factory=list)
    rejected: list[MemoryView] = Field(default_factory=list)

