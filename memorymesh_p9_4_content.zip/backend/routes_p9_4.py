# Location: src/memorymesh/api/routers/read.py (Lines 172-205)
@router.get(
    "/timeline",
    response_model=list[SlotTimeline],
    status_code=status.HTTP_200_OK,
    summary="Get timeline grouped by entity and attribute slot",
)
def get_timeline(
    service: Annotated[MemoryService, Depends(get_service)],
    entity: str | None = None,
    attribute: str | None = None,
    now: datetime | None = None,
) -> list[SlotTimeline]:
    """Retrieve memories and rejected claims grouped into temporal slot lanes."""
    validate_tz_aware(now, "now")
    return service.get_timeline(entity=entity, attribute=attribute, now=now)


@router.get(
    "/graph",
    response_model=GraphResponse,
    status_code=status.HTTP_200_OK,
    summary="Get entity and memory dependency graph",
)
def get_graph(
    service: Annotated[MemoryService, Depends(get_service)],
    entity: str | None = None,
    now: datetime | None = None,
) -> GraphResponse:
    """Construct dependency and relationship graph for entities and memories."""
    validate_tz_aware(now, "now")
    return service.get_graph(entity=entity, now=now)


@router.get(
