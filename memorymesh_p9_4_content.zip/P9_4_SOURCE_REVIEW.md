# MemoryMesh P9.4 — Complete Source Review & Verification Package

## 1. Git Status
```
 M frontend/src/api/client.ts
 M frontend/src/api/hooks.ts
 M frontend/src/pages/GraphPage.tsx
 M frontend/src/pages/TimelinePage.tsx
?? frontend/src/components/graph/
?? frontend/src/components/timeline/
?? frontend/src/lib/graphLayout.ts
?? frontend/src/lib/timeline.ts
?? frontend/test/p9_4_graph_timeline.test.ts
?? memorymesh_p9_4_content.zip

```

## 2. Backend Model Definitions (`src/memorymesh/models.py`)
```python
# Location: src/memorymesh/models.py (Lines 692-720, 767-775)
class GraphNode(MeshBaseModel):
    """Node in the memory/entity dependency and relationship graph."""

    id: str
    kind: Literal["entity", "memory"]
    label: str
    status: MemoryStatus | None = None
    confidence: float | None = None
    needs_review: bool = False
    meta: dict[str, Any] = Field(default_factory=dict)


class GraphEdge(MeshBaseModel):
    """Directed edge in the memory/entity graph."""

    id: str
    source: str
    target: str
    type: Literal["about", "supersedes", "refines", "contradicts", "depends_on"]
    reason: str = ""


class GraphResponse(MeshBaseModel):
    """Complete graph response containing nodes and edges."""

    nodes: list[GraphNode] = Field(default_factory=list)
    edges: list[GraphEdge] = Field(default_factory=list)



class SlotTimeline(MeshBaseModel):
    """Timeline lane for a specific entity attribute and context."""

    entity: str
    attribute: str
    context_key: str = ""
    memories: list[MemoryView] = Field(default_factory=list)
    rejected: list[MemoryView] = Field(default_factory=list)


```

## 3. Backend Route Implementations (`src/memorymesh/api/routers/read.py`)
```python
# Location: src/memorymesh/api/routers/read.py (Lines 172-205)
@router.get(
    "/timeline",
    response_model=list[SlotTimeline],
    status_code=status.HTTP_200_OK,
    summary="Get timeline grouped by entity and attribute slot",
)
def get_timeline(
    service: Annotated[MemoryService, Depends(get_service)],
    entity: str | None = None,
    attribute: str | None = None,
    now: datetime | None = None,
) -> list[SlotTimeline]:
    """Retrieve memories and rejected claims grouped into temporal slot lanes."""
    validate_tz_aware(now, "now")
    return service.get_timeline(entity=entity, attribute=attribute, now=now)


@router.get(
    "/graph",
    response_model=GraphResponse,
    status_code=status.HTTP_200_OK,
    summary="Get entity and memory dependency graph",
)
def get_graph(
    service: Annotated[MemoryService, Depends(get_service)],
    entity: str | None = None,
    now: datetime | None = None,
) -> GraphResponse:
    """Construct dependency and relationship graph for entities and memories."""
    validate_tz_aware(now, "now")
    return service.get_graph(entity=entity, now=now)


@router.get(

```

## File: `frontend/src/pages/GraphPage.tsx`

```typescript
import React, { useState, useMemo } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  type NodeTypes,
  type NodeMouseHandler,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { Share2, RefreshCw, Filter, Layers } from 'lucide-react';
import { useGraph, useCatalog } from '../api/hooks';
import { EntityNode } from '../components/graph/EntityNode';
import { MemoryNode } from '../components/graph/MemoryNode';
import { GraphDetailPanel } from '../components/graph/GraphDetailPanel';
import { ProvenanceDrawer } from '../components/memories/ProvenanceDrawer';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { ErrorState } from '../components/common/ErrorState';
import { EmptyState } from '../components/common/EmptyState';

// Register node types outside component to prevent re-creation
const nodeTypes: NodeTypes = {
  entity: EntityNode,
  memory: MemoryNode,
};

import {
  layoutGraphNodes,
  layoutGraphEdges,
} from '../lib/graphLayout';

export function GraphPage(): React.JSX.Element {
  const [selectedEntity, setSelectedEntity] = useState<string>('');
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [inspectMemoryId, setInspectMemoryId] = useState<number | null>(null);

  const { data: catalog } = useCatalog();
  const {
    data: graphData,
    isLoading,
    isError,
    error,
    refetch,
    isFetching,
  } = useGraph(selectedEntity ? { entity: selectedEntity } : undefined);

  const apiNodes = useMemo(() => graphData?.nodes ?? [], [graphData?.nodes]);
  const apiEdges = useMemo(() => graphData?.edges ?? [], [graphData?.edges]);

  const rfNodes = useMemo(() => layoutGraphNodes(apiNodes, apiEdges), [apiNodes, apiEdges]);
  const rfEdges = useMemo(() => layoutGraphEdges(apiEdges), [apiEdges]);

  const selectedNode = useMemo(
    () => apiNodes.find((n) => n.id === selectedNodeId) ?? null,
    [apiNodes, selectedNodeId]
  );

  const onNodeClick: NodeMouseHandler = (_, node) => {
    setSelectedNodeId(node.id);
  };

  const badgeClass =
    'px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-800 ' +
    'text-slate-300 border border-slate-700';

  const refreshBtnClass =
    'flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 ' +
    'hover:bg-slate-700 text-slate-200 text-xs font-medium border ' +
    'border-slate-700 transition-colors cursor-pointer disabled:opacity-50';

  const legendClass =
    'flex flex-wrap items-center gap-3 text-xs bg-slate-900/60 p-2.5 ' +
    'rounded-lg border border-slate-800 shrink-0';

  return (
    <div className="space-y-4 h-[calc(100vh-8rem)] flex flex-col">
      {/* Header & Controls */}
      <div
        className={
          'flex flex-wrap items-center justify-between gap-4 border-b ' +
          'border-slate-800 pb-3 shrink-0'
        }
      >
        <div>
          <div className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold text-white tracking-tight">Dependency Graph</h2>
            {apiNodes.length > 0 && (
              <span className={badgeClass}>
                {apiNodes.length} nodes · {apiEdges.length} edges
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Interactive React Flow visualization of memories, derivations, disputes, and relations.
          </p>
        </div>

        {/* Filters and Actions */}
        <div className="flex items-center gap-3">
          <div
            className={
              'flex items-center gap-2 bg-slate-900 border border-slate-800 ' +
              'rounded-lg px-2.5 py-1.5'
            }
          >
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedEntity}
              onChange={(e) => setSelectedEntity(e.target.value)}
              className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="">All Entities</option>
              {catalog?.entities?.map((ent, idx) => {
                const name =
                  typeof ent.name === 'string'
                    ? ent.name
                    : String(ent.name ?? `entity-${idx}`);
                return (
                  <option key={name} value={name}>
                    {name}
                  </option>
                );
              })}
            </select>
          </div>

          <button
            type="button"
            onClick={() => refetch()}
            disabled={isFetching}
            className={refreshBtnClass}
            title="Refresh graph"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isFetching ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Relationship Type Legend */}
      <div className={legendClass}>
        <span className="text-slate-400 font-semibold flex items-center gap-1">
          <Layers className="w-3.5 h-3.5" />
          Relations:
        </span>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-purple-400" />
          <span className="text-slate-300">supersedes</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
          <span className="text-slate-300">contradicts</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
          <span className="text-slate-300">depends_on</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
          <span className="text-slate-300">refines</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-slate-500" />
          <span className="text-slate-400">about</span>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div
        className={
          'flex-1 relative rounded-xl border border-slate-800 bg-slate-950 ' +
          'overflow-hidden flex'
        }
      >
        {isLoading && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-slate-950/80">
            <LoadingSpinner label="Loading dependency graph..." />
          </div>
        )}

        {isError && (
          <div className="absolute inset-0 z-10 flex items-center justify-center p-6">
            <ErrorState
              error={error}
              title="Failed to load graph"
              onRetry={() => refetch()}
            />
          </div>
        )}

        {!isLoading && !isError && apiNodes.length === 0 && (
          <div className="absolute inset-0 z-10 flex items-center justify-center p-6">
            <EmptyState
              icon={Share2}
              title="No Graph Nodes Found"
              description="Ingest messages to populate entities and memories in the graph."
            />
          </div>
        )}

        {/* React Flow Container */}
        <div className="flex-1 h-full">
          <ReactFlow
            nodes={rfNodes}
            edges={rfEdges}
            nodeTypes={nodeTypes}
            onNodeClick={onNodeClick}
            fitView
            minZoom={0.2}
            maxZoom={1.5}
            proOptions={{ hideAttribution: true }}
          >
            <Background color="#334155" gap={20} size={1} />
            <Controls
              className={
                'bg-slate-900 border border-slate-700 rounded text-slate-200 fill-slate-200'
              }
            />
            <MiniMap
              nodeColor={(node) => (node.type === 'entity' ? '#6366f1' : '#3b82f6')}
              className="bg-slate-900 border border-slate-800 rounded-lg"
              maskColor="rgba(15, 23, 42, 0.7)"
            />
          </ReactFlow>
        </div>

        {/* Node Detail Drawer / Panel */}
        {selectedNode && (
          <div className="absolute right-0 top-0 bottom-0 z-20">
            <GraphDetailPanel
              node={selectedNode}
              edges={apiEdges}
              onClose={() => setSelectedNodeId(null)}
              onInspectProvenance={(id) => setInspectMemoryId(id)}
            />
          </div>
        )}
      </div>

      {/* Provenance Drawer */}
      <ProvenanceDrawer
        memoryId={inspectMemoryId}
        onClose={() => setInspectMemoryId(null)}
      />
    </div>
  );
}

```

## File: `frontend/src/pages/TimelinePage.tsx`

```typescript
import React, { useState } from 'react';
import { Clock, RefreshCw, Filter, Layers } from 'lucide-react';
import { useTimeline, useCatalog } from '../api/hooks';
import { getTimelineLaneKey } from '../lib/timeline';
import { TimelineLaneCard } from '../components/timeline/TimelineLaneCard';
import { ProvenanceDrawer } from '../components/memories/ProvenanceDrawer';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { ErrorState } from '../components/common/ErrorState';
import { EmptyState } from '../components/common/EmptyState';

export function TimelinePage(): React.JSX.Element {
  const [selectedEntity, setSelectedEntity] = useState<string>('');
  const [selectedAttribute, setSelectedAttribute] = useState<string>('');
  const [inspectMemoryId, setInspectMemoryId] = useState<number | null>(null);

  const { data: catalog } = useCatalog();

  const queryParams = {
    entity: selectedEntity || undefined,
    attribute: selectedAttribute || undefined,
  };

  const {
    data: timelines,
    isLoading,
    isError,
    error,
    refetch,
    isFetching,
  } = useTimeline(queryParams);

  const lanes = timelines ?? [];

  const laneBadgeClass =
    'px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-800 ' +
    'text-slate-300 border border-slate-700';

  const filterBoxClass =
    'flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5';

  const refreshBtnClass =
    'flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 ' +
    'hover:bg-slate-700 text-slate-200 text-xs font-medium border ' +
    'border-slate-700 transition-colors cursor-pointer disabled:opacity-50';

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div
        className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4"
      >
        <div>
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold text-white tracking-tight">Slot Timeline</h2>
            {lanes.length > 0 && (
              <span className={laneBadgeClass}>
                {lanes.length} {lanes.length === 1 ? 'lane' : 'lanes'}
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Temporal visualization of memory lifecycles, validity intervals, and revisions.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Entity Filter */}
          <div className={filterBoxClass}>
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedEntity}
              onChange={(e) => setSelectedEntity(e.target.value)}
              className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="">All Entities</option>
              {catalog?.entities?.map((ent, idx) => {
                const name =
                  typeof ent.name === 'string'
                    ? ent.name
                    : String(ent.name ?? `entity-${idx}`);
                return (
                  <option key={name} value={name}>
                    {name}
                  </option>
                );
              })}
            </select>
          </div>

          {/* Attribute Filter */}
          <div className={filterBoxClass}>
            <Layers className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedAttribute}
              onChange={(e) => setSelectedAttribute(e.target.value)}
              className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="">All Attributes</option>
              {catalog?.attributes?.map((attr) => (
                <option key={attr.attribute} value={attr.attribute}>
                  {attr.attribute}
                </option>
              ))}
            </select>
          </div>

          {/* Refresh Button */}
          <button
            type="button"
            onClick={() => refetch()}
            disabled={isFetching}
            className={refreshBtnClass}
            title="Refresh timeline"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isFetching ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Loading & Error States */}
      {isLoading && <LoadingSpinner label="Loading slot timelines..." />}

      {isError && (
        <ErrorState
          error={error}
          title="Failed to load timeline"
          onRetry={() => refetch()}
        />
      )}

      {/* Empty State */}
      {!isLoading && !isError && lanes.length === 0 && (
        <EmptyState
          icon={Clock}
          title="No Timeline Lanes"
          description="Ingest messages to see temporal slot lanes and historical memory revisions."
        />
      )}

      {/* Timeline Lanes List */}
      {!isLoading && !isError && lanes.length > 0 && (
        <div className="space-y-6">
          {lanes.map((lane) => {
            const laneKey = getTimelineLaneKey(lane);
            return (
              <TimelineLaneCard
                key={laneKey}
                lane={lane}
                onSelectMemory={(id) => setInspectMemoryId(id)}
              />
            );
          })}
        </div>
      )}

      {/* Provenance Detail Drawer */}
      <ProvenanceDrawer
        memoryId={inspectMemoryId}
        onClose={() => setInspectMemoryId(null)}
      />
    </div>
  );
}

```

## File: `frontend/src/components/graph/EntityNode.tsx`

```typescript
import React from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import { Box } from 'lucide-react';

export interface EntityNodeData extends Record<string, unknown> {
  id: string;
  label: string;
  meta?: Record<string, unknown>;
}

export function EntityNode({ data, selected }: NodeProps): React.JSX.Element {
  const nodeData = data as unknown as EntityNodeData;
  const containerClass = selected
    ? 'border-indigo-400 ring-2 ring-indigo-400/50 shadow-indigo-950/50'
    : 'border-indigo-700/60 hover:border-indigo-500';

  const baseClass =
    'px-4 py-3 rounded-xl bg-slate-900/95 border min-w-[180px] shadow-lg transition-all';
  const iconBoxClass =
    'p-2 rounded-lg bg-indigo-950/80 text-indigo-400 border border-indigo-800/60';

  return (
    <div className={`${baseClass} ${containerClass}`}>
      <Handle
        type="target"
        position={Position.Left}
        className="w-2.5 h-2.5 bg-indigo-500 border border-slate-900"
      />
      <div className="flex items-center gap-2.5">
        <div className={iconBoxClass}>
          <Box className="w-4 h-4" />
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">
              Entity
            </span>
          </div>
          <div
            className="text-sm font-semibold text-slate-100 truncate"
            title={nodeData.label}
          >
            {nodeData.label}
          </div>
        </div>
      </div>
      <Handle
        type="source"
        position={Position.Right}
        className="w-2.5 h-2.5 bg-indigo-500 border border-slate-900"
      />
    </div>
  );
}

```

## File: `frontend/src/components/graph/MemoryNode.tsx`

```typescript
import React from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import { AlertTriangle, Clock } from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { formatConfidence, formatValidityInterval } from '../../lib/format';

export interface MemoryNodeData extends Record<string, unknown> {
  id: string;
  label: string;
  status?: string | null;
  confidence?: number | null;
  needs_review?: boolean;
  meta?: {
    value?: string;
    valid_from?: string;
    valid_to?: string | null;
    entity?: string;
    attribute?: string;
    source_id?: string;
    context_key?: string;
  };
}

export function MemoryNode({ data, selected }: NodeProps): React.JSX.Element {
  const nodeData = data as unknown as MemoryNodeData;
  const numericId = nodeData.id.replace(/^mem:/, '');
  const status = nodeData.status ?? 'active';
  const meta = nodeData.meta ?? {};

  const borderClass = selected
    ? 'border-blue-400 ring-2 ring-blue-400/50 shadow-blue-950/50'
    : 'border-slate-700 hover:border-slate-500';

  const reviewBadgeClass =
    'flex items-center gap-1 text-[10px] font-medium text-amber-400 ' +
    'bg-amber-950/50 px-1.5 py-0.5 rounded border border-amber-800/50';

  const cardBase =
    'p-3.5 rounded-xl bg-slate-900/95 border min-w-[240px] max-w-[280px] shadow-lg transition-all';

  return (
    <div className={`${cardBase} ${borderClass}`}>
      <Handle
        type="target"
        position={Position.Left}
        className="w-2.5 h-2.5 bg-slate-400 border border-slate-900"
      />

      {/* Header: ID, Status, and Review Alert */}
      <div className="flex items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-800">
        <div className="flex items-center gap-1.5">
          <span className="font-mono text-xs font-semibold text-slate-400">
            #{numericId}
          </span>
          <StatusBadge status={status} />
        </div>
        {nodeData.needs_review && (
          <span className={reviewBadgeClass} title="Needs Review">
            <AlertTriangle className="w-3 h-3" />
            Review
          </span>
        )}
      </div>

      {/* Main label / Value */}
      <div className="mb-2">
        <div
          className="text-xs text-slate-400 font-medium truncate"
          title={meta.attribute}
        >
          {meta.attribute || 'Attribute'}
        </div>
        <div
          className="text-sm font-bold text-slate-100 truncate font-mono"
          title={meta.value || nodeData.label}
        >
          {meta.value || nodeData.label}
        </div>
      </div>

      {/* Footer: Confidence and Validity */}
      <div
        className={
          'flex items-center justify-between text-[11px] ' +
          'text-slate-400 pt-1 border-t border-slate-800/60'
        }
      >
        <div className="flex items-center gap-1">
          <span>Conf:</span>
          <span className="font-mono text-slate-200 font-medium">
            {formatConfidence(nodeData.confidence)}
          </span>
        </div>
        {(meta.valid_from || meta.valid_to) && (
          <div className="flex items-center gap-1 text-[10px] font-mono text-slate-400">
            <Clock className="w-3 h-3 text-slate-400" />
            <span>{formatValidityInterval(meta.valid_from, meta.valid_to)}</span>
          </div>
        )}
      </div>

      <Handle
        type="source"
        position={Position.Right}
        className="w-2.5 h-2.5 bg-slate-400 border border-slate-900"
      />
    </div>
  );
}

```

## File: `frontend/src/components/graph/GraphDetailPanel.tsx`

```typescript
import React from 'react';
import { X, Box, ShieldCheck, ExternalLink, AlertTriangle } from 'lucide-react';
import type { GraphNode, GraphEdge } from '../../api/client';
import { StatusBadge } from '../common/StatusBadge';
import { ConfidenceBar } from '../common/ConfidenceBar';
import { ValidityBar } from '../common/ValidityBar';

interface GraphDetailPanelProps {
  node: GraphNode | null;
  edges: GraphEdge[];
  onClose: () => void;
  onInspectProvenance?: (memoryId: number) => void;
}

export const GraphDetailPanel: React.FC<GraphDetailPanelProps> = ({
  node,
  edges,
  onClose,
  onInspectProvenance,
}) => {
  if (!node) return null;

  const isEntity = node.kind === 'entity';
  const memoryId = !isEntity ? parseInt(node.id.replace(/^mem:/, ''), 10) : null;
  const connectedEdges = edges.filter(
    (e) => e.source === node.id || e.target === node.id
  );

  const closeBtnClass =
    'p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 ' +
    'transition-colors cursor-pointer';

  const inspectBtnClass =
    'w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs ' +
    'font-medium text-white bg-blue-600 hover:bg-blue-500 transition-colors shadow ' +
    'cursor-pointer';

  const panelClass =
    'w-80 sm:w-96 bg-slate-900 border-l border-slate-800 p-5 flex flex-col ' +
    'h-full overflow-y-auto space-y-5 shadow-2xl';

  return (
    <div className={panelClass}>
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          {isEntity ? (
            <div
              className="p-1.5 rounded-lg bg-indigo-950 text-indigo-400 border border-indigo-800"
            >
              <Box className="w-4 h-4" />
            </div>
          ) : (
            <div className="p-1.5 rounded-lg bg-blue-950 text-blue-400 border border-blue-800">
              <ShieldCheck className="w-4 h-4" />
            </div>
          )}
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              {isEntity ? 'Entity Details' : `Memory #${memoryId}`}
            </span>
            <h3
              className="text-sm font-bold text-white truncate max-w-[200px]"
              title={node.label}
            >
              {node.label}
            </h3>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className={closeBtnClass}
          aria-label="Close details"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Entity Node Details */}
      {isEntity && (
        <div className="space-y-4 text-xs">
          <div>
            <span className="text-slate-400 font-medium block mb-1">Entity Name:</span>
            <div className="text-sm font-semibold text-slate-100">{node.label}</div>
          </div>
          <div>
            <span className="text-slate-400 font-medium block mb-1">Entity ID:</span>
            <div className="font-mono text-slate-300">{node.id}</div>
          </div>
        </div>
      )}

      {/* Memory Node Details */}
      {!isEntity && (
        <div className="space-y-4 text-xs">
          {/* Status & Review Flag */}
          <div className="flex items-center justify-between">
            <div>
              <span className="text-slate-400 font-medium block mb-1">Status:</span>
              <StatusBadge status={node.status ?? 'active'} />
            </div>
            {node.needs_review && (
              <span
                className={
                  'flex items-center gap-1 text-[11px] font-medium text-amber-400 ' +
                  'bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/80'
                }
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                Needs Review
              </span>
            )}
          </div>

          {/* Entity & Attribute */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-slate-400 font-medium block mb-0.5">Entity:</span>
              <span className="font-semibold text-slate-200">
                {(node.meta?.entity as string) || '—'}
              </span>
            </div>
            <div>
              <span className="text-slate-400 font-medium block mb-0.5">Attribute:</span>
              <span className="font-semibold text-slate-200">
                {(node.meta?.attribute as string) || '—'}
              </span>
            </div>
          </div>

          {/* Value Display */}
          <div>
            <span className="text-slate-400 font-medium block mb-1">Stored Value:</span>
            <div
              className={
                'p-2.5 rounded-lg bg-slate-950 font-mono text-sm text-blue-300 ' +
                'border border-slate-800 break-all'
              }
            >
              {typeof node.meta?.value === 'string'
                ? node.meta.value
                : node.label}
            </div>
          </div>

          {/* Confidence */}
          <div>
            <span className="text-slate-400 font-medium block mb-1">Confidence Score:</span>
            <ConfidenceBar score={node.confidence ?? 0} />
          </div>

          {/* Validity Window */}
          <div>
            <span className="text-slate-400 font-medium block mb-1">Valid Interval:</span>
            <ValidityBar
              validFrom={node.meta?.valid_from as string | undefined}
              validTo={node.meta?.valid_to as string | undefined}
            />
          </div>

          {/* Source ID */}
          {Boolean(node.meta?.source_id) && (
            <div>
              <span className="text-slate-400 font-medium block mb-0.5">Source:</span>
              <span className="font-mono text-slate-300">
                {String(node.meta?.source_id)}
              </span>
            </div>
          )}

          {/* Inspect Provenance action */}
          {memoryId !== null && Boolean(onInspectProvenance) && (
            <div className="pt-2">
              <button
                type="button"
                onClick={() => onInspectProvenance?.(memoryId)}
                className={inspectBtnClass}
              >
                <ExternalLink className="w-3.5 h-3.5" />
                Inspect Full Provenance
              </button>
            </div>
          )}
        </div>
      )}

      {/* Connected Edges & Relationships */}
      <div className="pt-3 border-t border-slate-800 text-xs">
        <span className="text-slate-400 font-semibold block mb-2">
          Relationships ({connectedEdges.length}):
        </span>
        {connectedEdges.length === 0 ? (
          <div className="text-slate-400 text-xs italic">No connected relationships.</div>
        ) : (
          <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
            {connectedEdges.map((e) => {
              const isSource = e.source === node.id;
              const otherNodeId = isSource ? e.target : e.source;
              const direction = isSource ? '→' : '←';
              return (
                <div
                  key={e.id}
                  className="p-2 rounded bg-slate-950/70 border border-slate-800/80 space-y-1"
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-slate-300 uppercase tracking-wider">
                      {e.type}
                    </span>
                    <span className="font-mono text-slate-400">
                      {direction} {otherNodeId}
                    </span>
                  </div>
                  {e.reason && (
                    <p className="text-[11px] text-slate-400 leading-snug">{e.reason}</p>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

```

## File: `frontend/src/components/timeline/TimelineLaneCard.tsx`

```typescript
import React from 'react';
import {
  Clock,
  Calendar,
  XCircle,
  ExternalLink,
  AlertTriangle,
  History,
} from 'lucide-react';
import type { SlotTimeline, MemoryView } from '../../api/client';
import { StatusBadge } from '../common/StatusBadge';
import { ConfidenceBar } from '../common/ConfidenceBar';
import { ValidityBar } from '../common/ValidityBar';
import { formatUtcDateTime } from '../../lib/format';
import { getTimelineLaneStats } from '../../lib/timeline';

interface TimelineLaneCardProps {
  lane: SlotTimeline;
  onSelectMemory: (id: number) => void;
}

export const TimelineLaneCard: React.FC<TimelineLaneCardProps> = ({
  lane,
  onSelectMemory,
}) => {
  const memories = lane.memories ?? [];
  const rejected = lane.rejected ?? [];

  const { activeCount, historicalCount, rejectedCount } = getTimelineLaneStats(lane);

  const headerIconClass =
    'p-2 rounded-lg bg-indigo-950/80 text-indigo-400 border border-indigo-800/60';
  const attrBadgeClass =
    'px-2 py-0.5 rounded text-xs font-semibold bg-indigo-900/50 ' +
    'text-indigo-300 border border-indigo-700/50';
  const ctxBadgeClass =
    'px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-800 ' +
    'text-slate-300 border border-slate-700';

  const activePillClass =
    'px-2 py-0.5 rounded-full bg-emerald-950/60 text-emerald-300 ' +
    'border border-emerald-800/80 font-medium';
  const histPillClass =
    'px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 font-medium';
  const rejPillClass =
    'px-2 py-0.5 rounded-full bg-rose-950/60 text-rose-300 border border-rose-800/80 font-medium';

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-5 shadow-lg">
      {/* Lane Header */}
      <div
        className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800"
      >
        <div className="flex items-center gap-2.5">
          <div className={headerIconClass}>
            <History className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-base text-white">{lane.entity}</span>
              <span className={attrBadgeClass}>{lane.attribute}</span>
              {lane.context_key && (
                <span className={ctxBadgeClass}>{lane.context_key}</span>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Temporal slot lane for entity attribute changes and validity intervals.
            </p>
          </div>
        </div>

        {/* Counter Pills */}
        <div className="flex items-center gap-2 text-xs">
          {activeCount > 0 && <span className={activePillClass}>{activeCount} active</span>}
          {historicalCount > 0 && (
            <span className={histPillClass}>
              {historicalCount} historical/superseded
            </span>
          )}
          {rejectedCount > 0 && (
            <span className={rejPillClass}>{rejectedCount} rejected</span>
          )}
        </div>
      </div>

      {/* Accepted Memory Evolution */}
      <div className="space-y-3">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 block">
          Memory Evolution ({memories.length})
        </span>

        {memories.length === 0 ? (
          <div className="text-xs text-slate-400 italic py-2">
            No accepted memories in this slot lane.
          </div>
        ) : (
          <div className="space-y-3">
            {memories.map((mv: MemoryView) => {
              const mem = mv.memory;
              const cardBg =
                mem.status === 'active'
                  ? 'bg-slate-900/90 border-blue-500/40 shadow-sm'
                  : 'bg-slate-950/70 border-slate-800/80';
              const valClass =
                'font-mono text-sm font-bold text-slate-100 bg-slate-950 ' +
                'px-2.5 py-0.5 rounded border border-slate-800';

              return (
                <div key={mem.id} className={`p-4 rounded-xl border transition-all ${cardBg}`}>
                  <div className="flex flex-wrap items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-slate-400">
                        #{mem.id}
                      </span>
                      <StatusBadge
                        status={mem.status}
                        needsReview={mem.needs_review}
                      />
                      <span className={valClass}>
                        {mem.value_display || mem.value_norm}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onSelectMemory(mem.id)}
                      className={
                        'flex items-center gap-1 text-xs font-medium text-blue-400 ' +
                        'hover:text-blue-300 transition-colors cursor-pointer'
                      }
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Provenance
                    </button>
                  </div>

                  {/* Dual-Time & Temporal Information */}
                  <div
                    className={
                      'grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-2 ' +
                      'border-t border-slate-800/60'
                    }
                  >
                    {/* Bitemporal Dimension 1: Valid Time */}
                    <div className="space-y-1">
                      <span
                        className="text-slate-400 font-semibold flex items-center gap-1 text-[11px]"
                      >
                        <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                        Valid Time (World Time):
                      </span>
                      <ValidityBar validFrom={mem.valid_from} validTo={mem.valid_to} />
                    </div>

                    {/* Bitemporal Dimension 2: Recorded / Belief Time */}
                    <div className="space-y-1">
                      <span
                        className="text-slate-400 font-semibold flex items-center gap-1 text-[11px]"
                      >
                        <Clock className="w-3.5 h-3.5 text-blue-400" />
                        Recorded Time (System Time):
                      </span>
                      <div
                        className={
                          'font-mono text-[11px] text-slate-300 bg-slate-950 px-2 ' +
                          'py-1 rounded border border-slate-800 inline-block'
                        }
                      >
                        Learned: {formatUtcDateTime(mem.recorded_at)}
                        {mem.closed_at && (
                          <span className="text-slate-400 block text-[10px]">
                            Closed: {formatUtcDateTime(mem.closed_at)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Confidence & Source */}
                  <div
                    className={
                      'flex flex-wrap items-center justify-between gap-3 text-xs ' +
                      'text-slate-400 pt-3 mt-2 border-t border-slate-800/40'
                    }
                  >
                    <div className="flex items-center gap-2 w-48">
                      <span className="shrink-0 text-[11px]">Confidence:</span>
                      <ConfidenceBar score={mv.effective_confidence} />
                    </div>

                    <div className="flex items-center gap-3 text-[11px]">
                      {mv.source_names && mv.source_names.length > 0 && (
                        <span>
                          Source:{' '}
                          <span className="text-slate-300 font-mono">
                            {mv.source_names.join(', ')}
                          </span>
                        </span>
                      )}
                      {mem.review_reason && (
                        <span className="text-amber-400 flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          {mem.review_reason}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Rejected Claims Section (with Rejected-Memory Markers) */}
      {rejected.length > 0 && (
        <div className="pt-3 border-t border-slate-800 space-y-3">
          <div className="flex items-center gap-2">
            <XCircle className="w-4 h-4 text-rose-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-rose-300">
              Rejected Memory Markers ({rejected.length})
            </span>
          </div>

          <div className="space-y-2">
            {rejected.map((rej: MemoryView) => {
              const mem = rej.memory;
              const rejBadgeClass =
                'px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ' +
                'bg-rose-950 text-rose-300 border border-rose-800/80';
              return (
                <div
                  key={mem.id}
                  className={
                    'p-3 rounded-lg bg-rose-950/20 border border-rose-900/40 flex ' +
                    'flex-wrap items-center justify-between gap-3 text-xs'
                  }
                >
                  <div className="flex items-center gap-2.5">
                    <span className={rejBadgeClass}>Rejected</span>
                    <span className="font-mono font-semibold text-rose-200">
                      {mem.value_display || mem.value_norm}
                    </span>
                    <span className="text-slate-400 text-[11px]">
                      via {mem.source_id || 'unknown'} at{' '}
                      {formatUtcDateTime(mem.valid_from)}
                    </span>
                  </div>

                  {mem.review_reason && (
                    <span className="text-rose-400/90 text-xs italic">
                      Reason: {mem.review_reason}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

```

## File: `frontend/src/lib/graphLayout.ts`

```typescript
import { MarkerType, type Node, type Edge } from '@xyflow/react';
import type { GraphNode, GraphEdge } from '../api/client';

/**
 * Transforms backend API graph nodes into React Flow nodes with deterministic DAG layout.
 * Entity nodes are positioned on the left column (x=50), and their associated memory nodes
 * are arranged in columns to the right (x=360 for active, x=680 for historical/rejected).
 * Any orphan memory nodes without matching entities are positioned below.
 */
export function layoutGraphNodes(
  apiNodes: GraphNode[] = [],
  apiEdges: GraphEdge[] = []
): Node[] {
  const entityNodes = (apiNodes ?? []).filter((n) => n.kind === 'entity');
  const memoryNodes = (apiNodes ?? []).filter((n) => n.kind === 'memory');

  const memoryToEntityMap = new Map<string, string>();
  for (const edge of apiEdges ?? []) {
    if (edge.type === 'about') {
      memoryToEntityMap.set(edge.source, edge.target);
    }
  }

  const entityMemoriesMap = new Map<string, GraphNode[]>();
  for (const ent of entityNodes) {
    entityMemoriesMap.set(ent.id, []);
  }
  const orphanMemories: GraphNode[] = [];

  for (const mem of memoryNodes) {
    const entId = memoryToEntityMap.get(mem.id);
    if (entId && entityMemoriesMap.has(entId)) {
      entityMemoriesMap.get(entId)!.push(mem);
    } else {
      orphanMemories.push(mem);
    }
  }

  const nodes: Node[] = [];
  let currentY = 50;

  for (const ent of entityNodes) {
    const startY = currentY;
    nodes.push({
      id: ent.id,
      type: 'entity',
      position: { x: 50, y: startY + 20 },
      data: { id: ent.id, label: ent.label, meta: ent.meta },
    });

    const memories = entityMemoriesMap.get(ent.id) ?? [];
    memories.forEach((mem, idx) => {
      const isHistorical =
        mem.status === 'historical' || mem.status === 'rejected';
      const col = isHistorical ? 1 : 0;
      const x = 360 + col * 320;
      const y = startY + idx * 140;

      nodes.push({
        id: mem.id,
        type: 'memory',
        position: { x, y },
        data: {
          id: mem.id,
          label: mem.label,
          status: mem.status,
          confidence: mem.confidence,
          needs_review: mem.needs_review,
          meta: mem.meta,
        },
      });
    });

    const entityHeight = Math.max(1, memories.length) * 150 + 60;
    currentY += entityHeight;
  }

  if (orphanMemories.length > 0) {
    orphanMemories.forEach((mem, idx) => {
      nodes.push({
        id: mem.id,
        type: 'memory',
        position: { x: 360, y: currentY + idx * 140 },
        data: {
          id: mem.id,
          label: mem.label,
          status: mem.status,
          confidence: mem.confidence,
          needs_review: mem.needs_review,
          meta: mem.meta,
        },
      });
    });
  }

  return nodes;
}

/**
 * Transforms backend API graph edges into styled React Flow edges.
 * Colors and dash styles reflect edge semantics (about, supersedes, refines, etc.).
 */
export function layoutGraphEdges(apiEdges: GraphEdge[] = []): Edge[] {
  return (apiEdges ?? []).map((e) => {
    let stroke = '#64748b';
    let strokeDasharray: string | undefined = undefined;

    switch (e.type) {
      case 'supersedes':
        stroke = '#c084fc';
        break;
      case 'contradicts':
        stroke = '#fbbf24';
        break;
      case 'depends_on':
        stroke = '#34d399';
        break;
      case 'refines':
        stroke = '#22d3ee';
        break;
      case 'about':
        stroke = '#64748b';
        strokeDasharray = '4 4';
        break;
    }

    return {
      id: e.id,
      source: e.source,
      target: e.target,
      label: e.type,
      labelStyle: { fill: '#94a3b8', fontSize: 10, fontWeight: 600 },
      labelBgStyle: { fill: '#0f172a', fillOpacity: 0.8 },
      labelBgPadding: [4, 2] as [number, number],
      style: { stroke, strokeWidth: 1.5, strokeDasharray },
      markerEnd: {
        type: MarkerType.ArrowClosed,
        color: stroke,
        width: 14,
        height: 14,
      },
    };
  });
}

/**
 * Unified transformer from raw backend GraphResponse to React Flow nodes and edges.
 */
export function transformGraphResponse(graph?: {
  nodes?: GraphNode[];
  edges?: GraphEdge[];
}): { nodes: Node[]; edges: Edge[] } {
  return {
    nodes: layoutGraphNodes(graph?.nodes ?? [], graph?.edges ?? []),
    edges: layoutGraphEdges(graph?.edges ?? []),
  };
}

```

## File: `frontend/src/lib/timeline.ts`

```typescript
import type { SlotTimeline } from '../api/client';

export interface TimelineLaneStats {
  activeCount: number;
  historicalCount: number;
  rejectedCount: number;
  totalCount: number;
}

/**
 * Generate a unique, deterministic key for a slot timeline lane.
 */
export function getTimelineLaneKey(lane: SlotTimeline): string {
  return `${lane.entity}-${lane.attribute}-${lane.context_key || ''}`;
}

/**
 * Compute summary statistics for a slot timeline lane.
 */
export function getTimelineLaneStats(lane: SlotTimeline): TimelineLaneStats {
  const memories = lane.memories ?? [];
  const rejected = lane.rejected ?? [];

  const activeCount = memories.filter(
    (m) => m.memory.status === 'active'
  ).length;
  const historicalCount = memories.filter(
    (m) => m.memory.status !== 'active'
  ).length;
  const rejectedCount = rejected.length;

  return {
    activeCount,
    historicalCount,
    rejectedCount,
    totalCount: memories.length + rejectedCount,
  };
}

```

## File: `frontend/src/api/client.ts`

```typescript
/**
 * Centralized API client for MemoryMesh FastAPI backend.
 *
 * Governed by docs/ARCHITECTURE.md Section 4b and docs/SPECIFICATION.md Section 7.
 */

import type { components } from './types';

export type Schemas = components['schemas'];
export type HealthResponse = Schemas['HealthResponse'];
export type CatalogResponse = Schemas['CatalogResponse'];
export type Memory = Schemas['Memory'];
export type MemoryView = Schemas['MemoryView'];
export type MemoryStatus = Schemas['MemoryStatus'];
export type DecisionLogEntry = Schemas['DecisionLogEntry'];
export type ResolutionDecision = DecisionLogEntry;
export type DisputeView = Schemas['DisputeView'];
export type GraphResponse = Schemas['GraphResponse'];
export type GraphNode = Schemas['GraphNode'];
export type GraphEdge = Schemas['GraphEdge'];
export type SlotTimeline = Schemas['SlotTimeline'];
export type IngestRequest = Schemas['IngestRequest'];
export type IngestReport = Schemas['IngestReport'];
export type AskRequest = Schemas['AskRequest'];
export type AskResponse = Schemas['AskResponse'];
export type AskResult = Schemas['AskResult'];
export type FinalAnswer = Schemas['FinalAnswer'];
export type BaselineHit = Schemas['BaselineHit'];
export type LLMCallLog = Schemas['LLMCallLog'];
export type EvalSummary = Schemas['EvalSummary'];
export type ResetResponse = Schemas['ResetResponse'];
export type ResolveDisputeRequest = Schemas['ResolveDisputeRequest'];
export type ImpactItem = Schemas['ImpactItem'];
export type QueryResult = Schemas['QueryResult'];

/**
 * Standardized API Error matching backend error envelope.
 * Backend envelope format: {"error": {"code": "string", "message": "string"}}
 */
export class ApiError extends Error {
  readonly code: string;
  readonly status: number;
  readonly details?: unknown;

  constructor(message: string, code = 'unknown_error', status = 500, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

/**
 * Resolve API base URL.
 * Defaults to empty string to use Vite's dev proxy (/api -> http://localhost:8000),
 * or respects VITE_API_BASE when provided in environment.
 */
function getApiBaseUrl(): string {
  const envBase = import.meta.env.VITE_API_BASE;
  if (!envBase) return '';
  // Strip trailing slash if present
  return envBase.endsWith('/') ? envBase.slice(0, -1) : envBase;
}

/**
 * Centralized fetch wrapper handling URL resolution, JSON serialization,
 * HTTP status validation, and error mapping.
 */
export async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const base = getApiBaseUrl();
  const normalizedEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  const url = `${base}${normalizedEndpoint}`;

  const headers: Record<string, string> = {
    Accept: 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (options.body && typeof options.body === 'string' && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  let response: Response;
  try {
    response = await fetch(url, {
      ...options,
      headers,
    });
  } catch (networkErr) {
    const errorMsg =
      networkErr instanceof Error ? networkErr.message : 'Network connection failed';
    throw new ApiError(
      `Unable to connect to MemoryMesh backend: ${errorMsg}`,
      'network_error',
      0
    );
  }

  // Handle successful text/json responses
  if (response.ok) {
    if (response.status === 204 || response.headers.get('content-length') === '0') {
      return {} as T;
    }
    const text = await response.text();
    if (!text) {
      return {} as T;
    }
    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      try {
        return JSON.parse(text) as T;
      } catch {
        return text as unknown as T;
      }
    }
    return text as unknown as T;
  }

  // Parse error envelope
  let errorData: unknown = null;
  try {
    errorData = await response.json();
  } catch {
    errorData = null;
  }

  let errorCode = 'http_error';
  let errorMessage = `HTTP ${response.status}: ${response.statusText || 'Request failed'}`;

  if (
    errorData &&
    typeof errorData === 'object' &&
    'error' in errorData &&
    typeof (errorData as { error: unknown }).error === 'object'
  ) {
    const envelope = (errorData as { error: { code?: string; message?: string } }).error;
    if (envelope.code) errorCode = envelope.code;
    if (envelope.message) errorMessage = envelope.message;
  } else if (
    errorData &&
    typeof errorData === 'object' &&
    'detail' in errorData
  ) {
    const detail = (errorData as { detail: unknown }).detail;
    errorCode = response.status === 422 ? 'validation_error' : 'http_error';
    if (typeof detail === 'string') {
      errorMessage = detail;
    } else if (Array.isArray(detail)) {
      errorMessage = detail
        .map((d: { loc?: unknown[]; msg?: string }) => {
          const field = Array.isArray(d.loc)
            ? d.loc.filter((part) => part !== 'body').join('.')
            : '';
          return field ? `${field}: ${d.msg}` : d.msg || 'Invalid field';
        })
        .join('; ');
    } else {
      errorMessage = JSON.stringify(detail);
    }
  } else if (response.status === 500) {
    errorCode = 'internal';
    errorMessage = 'An internal server error occurred while processing the request.';
  }

  throw new ApiError(errorMessage, errorCode, response.status, errorData);
}

/**
 * Query parameter serializer helper.
 */
function toQueryString(
  params?: Record<string, string | number | boolean | null | undefined>
): string {
  if (!params) return '';
  const searchParams = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== null && value !== undefined && value !== '') {
      searchParams.append(key, String(value));
    }
  }
  const qs = searchParams.toString();
  return qs ? `?${qs}` : '';
}

/**
 * Centralized API service object with strongly typed endpoint calls.
 */
export const api = {
  // Read operations
  getHealth: (): Promise<HealthResponse> =>
    apiRequest<HealthResponse>('/api/health'),

  getCatalog: (): Promise<CatalogResponse> =>
    apiRequest<CatalogResponse>('/api/catalog'),

  getMemories: (params?: {
    entity?: string;
    attribute?: string;
    status?: string;
    needs_review?: boolean;
    now?: string;
    limit?: number;
    offset?: number;
  }): Promise<MemoryView[]> =>
    apiRequest<MemoryView[]>(`/api/memories${toQueryString(params)}`),

  getMemory: (id: number, now?: string): Promise<MemoryView> =>
    apiRequest<MemoryView>(`/api/memories/${id}${toQueryString({ now })}`),

  explainMemory: (id: number): Promise<QueryResult> =>
    apiRequest<QueryResult>(`/api/memories/${id}/explain`),

  getMemoryImpact: (id: number): Promise<ImpactItem[]> =>
    apiRequest<ImpactItem[]>(`/api/memories/${id}/impact`),

  getTimeline: (params?: {
    entity?: string;
    attribute?: string;
    now?: string;
  }): Promise<SlotTimeline[]> =>
    apiRequest<SlotTimeline[]>(`/api/timeline${toQueryString(params)}`),

  getGraph: (params?: { entity?: string; now?: string }): Promise<GraphResponse> =>
    apiRequest<GraphResponse>(`/api/graph${toQueryString(params)}`),

  getDecisions: (params?: {
    action?: string;
    rule_id?: string;
    entity?: string;
    limit?: number;
    offset?: number;
  }): Promise<DecisionLogEntry[]> =>
    apiRequest<DecisionLogEntry[]>(`/api/decisions${toQueryString(params)}`),

  getLLMCalls: (params?: {
    prompt_id?: string;
    status?: string;
    limit?: number;
    offset?: number;
  }): Promise<LLMCallLog[]> =>
    apiRequest<LLMCallLog[]>(`/api/llm/calls${toQueryString(params)}`),

  getEvalSummary: (): Promise<EvalSummary> =>
    apiRequest<EvalSummary>('/api/eval/latest'),

  getEvalReport: (): Promise<string> =>
    apiRequest<string>('/api/eval/report'),

  // Write operations
  ingest: (body: IngestRequest): Promise<IngestReport> =>
    apiRequest<IngestReport>('/api/ingest', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  acknowledgeMemory: (
    id: number
  ): Promise<{ success: boolean; memory_id: number; unflagged: boolean }> =>
    apiRequest<{ success: boolean; memory_id: number; unflagged: boolean }>(
      `/api/memories/${id}/acknowledge`,
      { method: 'POST' }
    ),

  resolveDispute: (
    body: ResolveDisputeRequest
  ): Promise<{
    success: boolean;
    dispute_id: number;
    winner_memory_id: number;
    affected_memory_ids: number[];
  }> =>
    apiRequest<{
      success: boolean;
      dispute_id: number;
      winner_memory_id: number;
      affected_memory_ids: number[];
    }>('/api/disputes/resolve', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  resetDemo: (): Promise<ResetResponse> =>
    apiRequest<ResetResponse>('/api/demo/reset', {
      method: 'POST',
    }),

  ask: (body: AskRequest): Promise<AskResponse> =>
    apiRequest<AskResponse>('/api/ask', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
};

```

## File: `frontend/src/api/hooks.ts`

```typescript
/**
 * TanStack Query hooks and query-key infrastructure for MemoryMesh.
 *
 * Governed by docs/ARCHITECTURE.md Section 4b, docs/ROADMAP_AND_TASKS.md T9.2/T9.3,
 * and canonical plan P9.2/P9.3.
 */

import {
  useQuery,
  useMutation,
  useQueryClient,
  type UseQueryOptions,
  type UseMutationOptions,
} from '@tanstack/react-query';
import {
  api,
  type HealthResponse,
  type CatalogResponse,
  type ResetResponse,
  type MemoryView,
  type QueryResult,
  type IngestRequest,
  type IngestReport,
  type AskRequest,
  type AskResponse,
  type GraphResponse,
  type SlotTimeline,
  type ApiError,
} from './client';

/**
 * Standardized query key factory establishing conventions for caching and invalidation.
 */
export const queryKeys = {
  health: ['health'] as const,
  catalog: ['catalog'] as const,
  memories: (params?: Record<string, unknown>) => ['memories', params] as const,
  memory: (id: number, now?: string) => ['memory', id, now] as const,
  memoryExplain: (id: number) => ['memory', id, 'explain'] as const,
  memoryImpact: (id: number) => ['memory', id, 'impact'] as const,
  timeline: (params?: { entity?: string; attribute?: string; now?: string }) =>
    ['timeline', params] as const,
  graph: (params?: { entity?: string; now?: string }) =>
    ['graph', params] as const,
  decisions: (params?: Record<string, unknown>) => ['decisions', params] as const,
  llmCalls: (params?: Record<string, unknown>) => ['llmCalls', params] as const,
  evalSummary: ['evalSummary'] as const,
  evalReport: ['evalReport'] as const,
};

// ==============================================================================
// Shell Query Hooks (P9.2)
// ==============================================================================

/**
 * Fetch backend health, LLM provider info, and database status.
 */
export function useHealth(
  options?: Omit<UseQueryOptions<HealthResponse, ApiError>, 'queryKey' | 'queryFn'>
) {
  return useQuery<HealthResponse, ApiError>({
    queryKey: queryKeys.health,
    queryFn: () => api.getHealth(),
    refetchInterval: 30000,
    ...options,
  });
}

/**
 * Fetch configuration catalog (sources, attributes, entities, thresholds).
 */
export function useCatalog(
  options?: Omit<UseQueryOptions<CatalogResponse, ApiError>, 'queryKey' | 'queryFn'>
) {
  return useQuery<CatalogResponse, ApiError>({
    queryKey: queryKeys.catalog,
    queryFn: () => api.getCatalog(),
    staleTime: 5 * 60 * 1000,
    ...options,
  });
}

// ==============================================================================
// Memories & Provenance Query Hooks (P9.3)
// ==============================================================================

/**
 * List memories with optional filtering by entity, attribute, status, needs_review.
 */
export function useMemories(
  params?: {
    entity?: string;
    attribute?: string;
    status?: string;
    needs_review?: boolean;
    now?: string;
    limit?: number;
    offset?: number;
  },
  options?: Omit<UseQueryOptions<MemoryView[], ApiError>, 'queryKey' | 'queryFn'>
) {
  return useQuery<MemoryView[], ApiError>({
    queryKey: queryKeys.memories(params),
    queryFn: () => api.getMemories(params),
    ...options,
  });
}

/**
 * Retrieve a single memory by ID.
 */
export function useMemory(
  id: number,
  now?: string,
  options?: Omit<UseQueryOptions<MemoryView, ApiError>, 'queryKey' | 'queryFn'>
) {
  return useQuery<MemoryView, ApiError>({
    queryKey: queryKeys.memory(id, now),
    queryFn: () => api.getMemory(id, now),
    enabled: id > 0,
    ...options,
  });
}

/**
 * Explain provenance and decision reasoning for a memory.
 */
export function useMemoryExplain(
  id: number,
  options?: Omit<UseQueryOptions<QueryResult, ApiError>, 'queryKey' | 'queryFn'>
) {
  return useQuery<QueryResult, ApiError>({
    queryKey: queryKeys.memoryExplain(id),
    queryFn: () => api.explainMemory(id),
    enabled: id > 0,
    ...options,
  });
}

// ==============================================================================
// Graph and Timeline Query Hooks (P9.4)
// ==============================================================================

/**
 * Retrieve entity and memory dependency graph (P9.4).
 */
export function useGraph(
  params?: { entity?: string; now?: string },
  options?: Omit<UseQueryOptions<GraphResponse, ApiError>, 'queryKey' | 'queryFn'>
) {
  return useQuery<GraphResponse, ApiError>({
    queryKey: queryKeys.graph(params),
    queryFn: () => api.getGraph(params),
    ...options,
  });
}

/**
 * Retrieve slot timeline grouped by entity and attribute lanes (P9.4).
 */
export function useTimeline(
  params?: { entity?: string; attribute?: string; now?: string },
  options?: Omit<UseQueryOptions<SlotTimeline[], ApiError>, 'queryKey' | 'queryFn'>
) {
  return useQuery<SlotTimeline[], ApiError>({
    queryKey: queryKeys.timeline(params),
    queryFn: () => api.getTimeline(params),
    ...options,
  });
}

// ==============================================================================
// Mutation Hooks (P9.2 / P9.3)
// ==============================================================================

/**
 * Reset database and re-seed demo data.
 * Invalidates all queries across the application.
 */
export function useResetDemo(
  options?: UseMutationOptions<ResetResponse, ApiError, void>
) {
  const queryClient = useQueryClient();
  return useMutation<ResetResponse, ApiError, void>({
    mutationFn: () => api.resetDemo(),
    onSuccess: () => {
      queryClient.invalidateQueries();
    },
    ...options,
  });
}

/**
 * Ingest message and extract/resolve memory claims (P9.3).
 * On success, invalidates memory and decision queries.
 */
export function useIngest(
  options?: UseMutationOptions<IngestReport, ApiError, IngestRequest>
) {
  const queryClient = useQueryClient();
  return useMutation<IngestReport, ApiError, IngestRequest>({
    mutationFn: (body) => api.ingest(body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['memories'] });
      queryClient.invalidateQueries({ queryKey: ['decisions'] });
    },
    ...options,
  });
}

/**
 * Ask a natural language question with optional naive RAG comparison (P9.3).
 */
export function useAsk(
  options?: UseMutationOptions<AskResponse, ApiError, AskRequest>
) {
  return useMutation<AskResponse, ApiError, AskRequest>({
    mutationFn: (body) => api.ask(body),
    ...options,
  });
}

```

## File: `frontend/test/p9_4_graph_timeline.test.ts`

```typescript
import test from 'node:test';
import assert from 'node:assert/strict';
import type { GraphNode, GraphEdge, SlotTimeline } from '../src/api/client.ts';
import {
  layoutGraphNodes,
  layoutGraphEdges,
  transformGraphResponse,
} from '../src/lib/graphLayout.ts';
import { getTimelineLaneKey, getTimelineLaneStats } from '../src/lib/timeline.ts';
import { formatValidityInterval, formatUtcDateTime, formatConfidence } from '../src/lib/format.ts';

// ---------------------------------------------------------------------------
// Backend-Shaped Fixtures
// ---------------------------------------------------------------------------

const BACKEND_GRAPH_FIXTURE: { nodes: GraphNode[]; edges: GraphEdge[] } = {
  nodes: [
    {
      id: 'entity:1',
      kind: 'entity',
      label: 'Server A',
      status: null,
      confidence: null,
      needs_review: false,
      meta: { name: 'Server A', id: 1 },
    },
    {
      id: 'mem:1',
      kind: 'memory',
      label: 'python_version: 3.11',
      status: 'historical',
      confidence: 0.81,
      needs_review: false,
      meta: {
        value: '3.11',
        valid_from: '2026-06-01T10:00:00Z',
        valid_to: '2026-06-01T11:00:00Z',
        source_id: 'sysadmin_priya',
        entity: 'Server A',
        attribute: 'python_version',
        context_key: '',
      },
    },
    {
      id: 'mem:2',
      kind: 'memory',
      label: 'python_version: 3.12',
      status: 'active',
      confidence: 0.9,
      needs_review: true,
      meta: {
        value: '3.12',
        valid_from: '2026-06-01T11:00:00Z',
        valid_to: null,
        source_id: 'sysadmin_priya',
        entity: 'Server A',
        attribute: 'python_version',
        context_key: '',
      },
    },
  ],
  edges: [
    {
      id: 'about:1->1',
      source: 'mem:1',
      target: 'entity:1',
      type: 'about',
      reason: 'Memory 1 is about entity Server A',
    },
    {
      id: 'about:2->1',
      source: 'mem:2',
      target: 'entity:1',
      type: 'about',
      reason: 'Memory 2 is about entity Server A',
    },
    {
      id: 'edge:1',
      source: 'mem:2',
      target: 'mem:1',
      type: 'supersedes',
      reason: 'Server migrated from 3.11 to 3.12',
    },
  ],
};

// ---------------------------------------------------------------------------
// P9.4 Production Graph Transformation & Layout Tests
// ---------------------------------------------------------------------------

test('Production layoutGraphNodes: maps entity and memory nodes with DAG columns', () => {
  const nodes = layoutGraphNodes(
    BACKEND_GRAPH_FIXTURE.nodes,
    BACKEND_GRAPH_FIXTURE.edges
  );

  assert.equal(nodes.length, 3);

  // 1. Entity Node validation
  const entNode = nodes.find((n) => n.id === 'entity:1');
  assert.ok(entNode, 'Entity node entity:1 must exist in layout');
  assert.equal(entNode.type, 'entity');
  assert.equal(entNode.position.x, 50, 'Entity nodes must be placed at x=50');
  assert.deepEqual(entNode.data, {
    id: 'entity:1',
    label: 'Server A',
    meta: { name: 'Server A', id: 1 },
  });

  // 2. Active Memory Node validation (placed in primary active column x=360)
  const activeNode = nodes.find((n) => n.id === 'mem:2');
  assert.ok(activeNode, 'Memory node mem:2 must exist in layout');
  assert.equal(activeNode.type, 'memory');
  assert.equal(activeNode.position.x, 360, 'Active memory placed at x=360');
  assert.equal(activeNode.data.status, 'active');
  assert.equal(activeNode.data.confidence, 0.9);
  assert.equal(activeNode.data.needs_review, true);

  // 3. Historical Memory Node validation (placed in revision column x=680)
  const histNode = nodes.find((n) => n.id === 'mem:1');
  assert.ok(histNode, 'Memory node mem:1 must exist in layout');
  assert.equal(histNode.type, 'memory');
  assert.equal(histNode.position.x, 680, 'Historical memory placed at x=680');
  assert.equal(histNode.data.status, 'historical');
  assert.equal(histNode.data.confidence, 0.81);
  assert.equal(histNode.data.needs_review, false);
});

test('Production layoutGraphEdges: preserves memory -> entity direction and edge styles', () => {
  const edges = layoutGraphEdges(BACKEND_GRAPH_FIXTURE.edges);

  assert.equal(edges.length, 3);

  // 1. Verify "about" edge preserves memory -> entity direction
  const aboutEdges = edges.filter((e) => e.label === 'about');
  assert.equal(aboutEdges.length, 2);
  for (const edge of aboutEdges) {
    assert.match(edge.source, /^mem:\d+$/, 'about edge source must be a memory');
    assert.match(edge.target, /^entity:\d+$/, 'about edge target must be an entity');
    assert.equal(edge.style?.strokeDasharray, '4 4', 'about edge must be dashed');
    assert.equal(edge.style?.stroke, '#64748b', 'about edge stroke must be slate-500');
  }

  // 2. Verify "supersedes" relationship edge preserves source -> target
  const supersedesEdge = edges.find((e) => e.label === 'supersedes');
  assert.ok(supersedesEdge, 'supersedes edge must exist');
  assert.equal(supersedesEdge.id, 'edge:1');
  assert.equal(supersedesEdge.source, 'mem:2', 'source is superseding memory');
  assert.equal(supersedesEdge.target, 'mem:1', 'target is superseded memory');
  assert.equal(supersedesEdge.style?.stroke, '#c084fc', 'supersedes edge is purple');
  assert.ok(supersedesEdge.markerEnd, 'markerEnd arrow must be present');
});

test('Production layoutGraphEdges: handles all relationship edge types and styles', () => {
  const relationEdges: GraphEdge[] = [
    { id: 'e-sup', source: 'mem:2', target: 'mem:1', type: 'supersedes', reason: 'r1' },
    { id: 'e-ref', source: 'mem:3', target: 'mem:1', type: 'refines', reason: 'r2' },
    { id: 'e-con', source: 'mem:4', target: 'mem:5', type: 'contradicts', reason: 'r3' },
    { id: 'e-dep', source: 'mem:6', target: 'mem:7', type: 'depends_on', reason: 'r4' },
    { id: 'e-abt', source: 'mem:2', target: 'entity:1', type: 'about', reason: 'r5' },
  ];

  const edges = layoutGraphEdges(relationEdges);
  assert.equal(edges.length, 5);

  const styleMap = Object.fromEntries(
    edges.map((e) => [
      e.label,
      { stroke: e.style?.stroke, dashed: Boolean(e.style?.strokeDasharray) },
    ])
  );

  assert.deepEqual(styleMap['supersedes'], { stroke: '#c084fc', dashed: false });
  assert.deepEqual(styleMap['refines'], { stroke: '#22d3ee', dashed: false });
  assert.deepEqual(styleMap['contradicts'], { stroke: '#fbbf24', dashed: false });
  assert.deepEqual(styleMap['depends_on'], { stroke: '#34d399', dashed: false });
  assert.deepEqual(styleMap['about'], { stroke: '#64748b', dashed: true });
});

test('Production layoutGraphNodes: safely handles orphan memories and missing endpoints', () => {
  const unlinkedNodes: GraphNode[] = [
    {
      id: 'entity:1',
      kind: 'entity',
      label: 'Server A',
      meta: {},
    },
    {
      id: 'mem:10',
      kind: 'memory',
      label: 'status: online',
      status: 'active',
      meta: {},
    },
    {
      id: 'mem:99',
      kind: 'memory',
      label: 'orphan_attr: val',
      status: 'active',
      meta: {},
    },
  ];

  // mem:10 links to entity:1, but mem:99 links to nonexistent entity:999
  const unlinkedEdges: GraphEdge[] = [
    { id: 'a1', source: 'mem:10', target: 'entity:1', type: 'about' },
    { id: 'a2', source: 'mem:99', target: 'entity:999', type: 'about' },
    { id: 'e1', source: 'mem:99', target: 'mem:888', type: 'depends_on' },
  ];

  // Layout should not crash and should position orphan memory safely
  const nodes = layoutGraphNodes(unlinkedNodes, unlinkedEdges);
  assert.equal(nodes.length, 3);

  const orphanNode = nodes.find((n) => n.id === 'mem:99');
  assert.ok(orphanNode, 'Orphan memory node must be preserved');
  assert.equal(orphanNode.type, 'memory');
  assert.equal(orphanNode.position.x, 360);

  const edges = layoutGraphEdges(unlinkedEdges);
  assert.equal(edges.length, 3);
});

test('Production transformGraphResponse: safely handles empty and undefined graphs', () => {
  const emptyRes = transformGraphResponse({ nodes: [], edges: [] });
  assert.deepEqual(emptyRes.nodes, []);
  assert.deepEqual(emptyRes.edges, []);

  const undefRes = transformGraphResponse(undefined);
  assert.deepEqual(undefRes.nodes, []);
  assert.deepEqual(undefRes.edges, []);

  const partialRes = transformGraphResponse({});
  assert.deepEqual(partialRes.nodes, []);
  assert.deepEqual(partialRes.edges, []);
});

// ---------------------------------------------------------------------------
// P9.4 Production Timeline Transformation Tests
// ---------------------------------------------------------------------------

test('Production getTimelineLaneKey: generates deterministic keys for slot lanes', () => {
  const globalLane: SlotTimeline = {
    entity: 'Server A',
    attribute: 'python_version',
    context_key: '',
  };
  assert.equal(getTimelineLaneKey(globalLane), 'Server A-python_version-');

  const contextualLane: SlotTimeline = {
    entity: 'Server A',
    attribute: 'config_path',
    context_key: 'env=prod;region=us-east',
  };
  assert.equal(
    getTimelineLaneKey(contextualLane),
    'Server A-config_path-env=prod;region=us-east'
  );
});

test('Production getTimelineLaneStats: calculates active, historical, and rejected', () => {
  const laneWithMemories: SlotTimeline = {
    entity: 'Server A',
    attribute: 'python_version',
    context_key: '',
    memories: [
      {
        memory: {
          id: 1,
          entity_id: 1,
          entity_name: 'Server A',
          attribute: 'python_version',
          value_norm: '3.11',
          value_display: '3.11',
          context: {},
          context_key: '',
          valid_from: '2026-06-01T10:00:00Z',
          valid_to: '2026-06-01T11:00:00Z',
          recorded_at: '2026-06-01T10:00:00Z',
          closed_at: '2026-06-01T11:00:00Z',
          status: 'historical',
          confidence: 0.81,
          needs_review: false,
          review_reason: '',
          raw_text: '',
          message_id: 1,
          source_id: 'sysadmin',
          evidence: [],
        },
        effective_confidence: 0.81,
        is_stale: false,
        source_names: ['sysadmin'],
        scope_match: 'exact',
      },
      {
        memory: {
          id: 2,
          entity_id: 1,
          entity_name: 'Server A',
          attribute: 'python_version',
          value_norm: '3.12',
          value_display: '3.12',
          context: {},
          context_key: '',
          valid_from: '2026-06-01T11:00:00Z',
          valid_to: null,
          recorded_at: '2026-06-01T11:00:00Z',
          closed_at: null,
          status: 'active',
          confidence: 0.9,
          needs_review: false,
          review_reason: '',
          raw_text: '',
          message_id: 2,
          source_id: 'sysadmin',
          evidence: [],
        },
        effective_confidence: 0.9,
        is_stale: false,
        source_names: ['sysadmin'],
        scope_match: 'exact',
      },
    ],
    rejected: [
      {
        memory: {
          id: 99,
          entity_id: 1,
          entity_name: 'Server A',
          attribute: 'python_version',
          value_norm: '2.7',
          value_display: '2.7',
          context: {},
          context_key: '',
          valid_from: '2026-06-01T09:00:00Z',
          valid_to: null,
          recorded_at: '2026-06-01T09:00:00Z',
          closed_at: null,
          status: 'rejected',
          confidence: 0.3,
          needs_review: true,
          review_reason: 'Contradicted',
          raw_text: '',
          message_id: 3,
          source_id: 'contractor',
          evidence: [],
        },
        effective_confidence: 0.0,
        is_stale: false,
        source_names: ['contractor'],
        scope_match: 'exact',
      },
    ],
  };

  const stats = getTimelineLaneStats(laneWithMemories);
  assert.equal(stats.activeCount, 1, 'Exactly 1 active memory');
  assert.equal(stats.historicalCount, 1, 'Exactly 1 historical memory');
  assert.equal(stats.rejectedCount, 1, 'Exactly 1 rejected memory');
  assert.equal(stats.totalCount, 3, 'Total count includes accepted and rejected');

  // Edge case: empty/missing memories and rejected
  const emptyStats = getTimelineLaneStats({
    entity: 'Server B',
    attribute: 'os_name',
    context_key: '',
  });
  assert.equal(emptyStats.activeCount, 0);
  assert.equal(emptyStats.historicalCount, 0);
  assert.equal(emptyStats.rejectedCount, 0);
  assert.equal(emptyStats.totalCount, 0);
});

test('Timeline Formatting: correctly presents bitemporal intervals and confidence', () => {
  const activeInterval = formatValidityInterval('2026-06-01T11:00:00Z', null);
  assert.equal(activeInterval, '2026-06-01 → Present');

  const closedInterval = formatValidityInterval(
    '2026-06-01T10:00:00Z',
    '2026-06-01T11:00:00Z'
  );
  assert.equal(closedInterval, '2026-06-01 → 2026-06-01');

  assert.match(
    formatUtcDateTime('2026-06-01T11:00:00Z'),
    /2026-06-01 11:00:00 UTC/
  );
  assert.equal(formatConfidence(0.8123), '81.2%');
  assert.equal(formatConfidence(null), '—');
});

```

## 4. Git Diff Output (`git diff HEAD`)

```diff
diff --git a/frontend/src/api/client.ts b/frontend/src/api/client.ts
index b067e73..c989b31 100644
--- a/frontend/src/api/client.ts
+++ b/frontend/src/api/client.ts
@@ -16,6 +16,8 @@ export type DecisionLogEntry = Schemas['DecisionLogEntry'];
 export type ResolutionDecision = DecisionLogEntry;
 export type DisputeView = Schemas['DisputeView'];
 export type GraphResponse = Schemas['GraphResponse'];
+export type GraphNode = Schemas['GraphNode'];
+export type GraphEdge = Schemas['GraphEdge'];
 export type SlotTimeline = Schemas['SlotTimeline'];
 export type IngestRequest = Schemas['IngestRequest'];
 export type IngestReport = Schemas['IngestReport'];
@@ -215,10 +217,14 @@ export const api = {
   getMemoryImpact: (id: number): Promise<ImpactItem[]> =>
     apiRequest<ImpactItem[]>(`/api/memories/${id}/impact`),
 
-  getTimeline: (params?: { entity?: string; attribute?: string }): Promise<SlotTimeline> =>
-    apiRequest<SlotTimeline>(`/api/timeline${toQueryString(params)}`),
+  getTimeline: (params?: {
+    entity?: string;
+    attribute?: string;
+    now?: string;
+  }): Promise<SlotTimeline[]> =>
+    apiRequest<SlotTimeline[]>(`/api/timeline${toQueryString(params)}`),
 
-  getGraph: (params?: { seed_id?: number; depth?: number }): Promise<GraphResponse> =>
+  getGraph: (params?: { entity?: string; now?: string }): Promise<GraphResponse> =>
     apiRequest<GraphResponse>(`/api/graph${toQueryString(params)}`),
 
   getDecisions: (params?: {
diff --git a/frontend/src/api/hooks.ts b/frontend/src/api/hooks.ts
index 8475ec7..8f29459 100644
--- a/frontend/src/api/hooks.ts
+++ b/frontend/src/api/hooks.ts
@@ -23,6 +23,8 @@ import {
   type IngestReport,
   type AskRequest,
   type AskResponse,
+  type GraphResponse,
+  type SlotTimeline,
   type ApiError,
 } from './client';
 
@@ -36,9 +38,9 @@ export const queryKeys = {
   memory: (id: number, now?: string) => ['memory', id, now] as const,
   memoryExplain: (id: number) => ['memory', id, 'explain'] as const,
   memoryImpact: (id: number) => ['memory', id, 'impact'] as const,
-  timeline: (params?: { entity?: string; attribute?: string }) =>
+  timeline: (params?: { entity?: string; attribute?: string; now?: string }) =>
     ['timeline', params] as const,
-  graph: (params?: { seed_id?: number; depth?: number }) =>
+  graph: (params?: { entity?: string; now?: string }) =>
     ['graph', params] as const,
   decisions: (params?: Record<string, unknown>) => ['decisions', params] as const,
   llmCalls: (params?: Record<string, unknown>) => ['llmCalls', params] as const,
@@ -135,6 +137,38 @@ export function useMemoryExplain(
   });
 }
 
+// ==============================================================================
+// Graph and Timeline Query Hooks (P9.4)
+// ==============================================================================
+
+/**
+ * Retrieve entity and memory dependency graph (P9.4).
+ */
+export function useGraph(
+  params?: { entity?: string; now?: string },
+  options?: Omit<UseQueryOptions<GraphResponse, ApiError>, 'queryKey' | 'queryFn'>
+) {
+  return useQuery<GraphResponse, ApiError>({
+    queryKey: queryKeys.graph(params),
+    queryFn: () => api.getGraph(params),
+    ...options,
+  });
+}
+
+/**
+ * Retrieve slot timeline grouped by entity and attribute lanes (P9.4).
+ */
+export function useTimeline(
+  params?: { entity?: string; attribute?: string; now?: string },
+  options?: Omit<UseQueryOptions<SlotTimeline[], ApiError>, 'queryKey' | 'queryFn'>
+) {
+  return useQuery<SlotTimeline[], ApiError>({
+    queryKey: queryKeys.timeline(params),
+    queryFn: () => api.getTimeline(params),
+    ...options,
+  });
+}
+
 // ==============================================================================
 // Mutation Hooks (P9.2 / P9.3)
 // ==============================================================================
diff --git a/frontend/src/pages/GraphPage.tsx b/frontend/src/pages/GraphPage.tsx
index 5e7c480..59d77d2 100644
--- a/frontend/src/pages/GraphPage.tsx
+++ b/frontend/src/pages/GraphPage.tsx
@@ -1,21 +1,247 @@
-import React from 'react';
-import { Share2 } from 'lucide-react';
+import React, { useState, useMemo } from 'react';
+import {
+  ReactFlow,
+  Background,
+  Controls,
+  MiniMap,
+  type NodeTypes,
+  type NodeMouseHandler,
+} from '@xyflow/react';
+import '@xyflow/react/dist/style.css';
+import { Share2, RefreshCw, Filter, Layers } from 'lucide-react';
+import { useGraph, useCatalog } from '../api/hooks';
+import { EntityNode } from '../components/graph/EntityNode';
+import { MemoryNode } from '../components/graph/MemoryNode';
+import { GraphDetailPanel } from '../components/graph/GraphDetailPanel';
+import { ProvenanceDrawer } from '../components/memories/ProvenanceDrawer';
+import { LoadingSpinner } from '../components/common/LoadingSpinner';
+import { ErrorState } from '../components/common/ErrorState';
 import { EmptyState } from '../components/common/EmptyState';
 
+// Register node types outside component to prevent re-creation
+const nodeTypes: NodeTypes = {
+  entity: EntityNode,
+  memory: MemoryNode,
+};
+
+import {
+  layoutGraphNodes,
+  layoutGraphEdges,
+} from '../lib/graphLayout';
+
 export function GraphPage(): React.JSX.Element {
+  const [selectedEntity, setSelectedEntity] = useState<string>('');
+  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
+  const [inspectMemoryId, setInspectMemoryId] = useState<number | null>(null);
+
+  const { data: catalog } = useCatalog();
+  const {
+    data: graphData,
+    isLoading,
+    isError,
+    error,
+    refetch,
+    isFetching,
+  } = useGraph(selectedEntity ? { entity: selectedEntity } : undefined);
+
+  const apiNodes = useMemo(() => graphData?.nodes ?? [], [graphData?.nodes]);
+  const apiEdges = useMemo(() => graphData?.edges ?? [], [graphData?.edges]);
+
+  const rfNodes = useMemo(() => layoutGraphNodes(apiNodes, apiEdges), [apiNodes, apiEdges]);
+  const rfEdges = useMemo(() => layoutGraphEdges(apiEdges), [apiEdges]);
+
+  const selectedNode = useMemo(
+    () => apiNodes.find((n) => n.id === selectedNodeId) ?? null,
+    [apiNodes, selectedNodeId]
+  );
+
+  const onNodeClick: NodeMouseHandler = (_, node) => {
+    setSelectedNodeId(node.id);
+  };
+
+  const badgeClass =
+    'px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-800 ' +
+    'text-slate-300 border border-slate-700';
+
+  const refreshBtnClass =
+    'flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 ' +
+    'hover:bg-slate-700 text-slate-200 text-xs font-medium border ' +
+    'border-slate-700 transition-colors cursor-pointer disabled:opacity-50';
+
+  const legendClass =
+    'flex flex-wrap items-center gap-3 text-xs bg-slate-900/60 p-2.5 ' +
+    'rounded-lg border border-slate-800 shrink-0';
+
   return (
-    <div className="space-y-6">
-      <div className="border-b border-slate-800 pb-4">
-        <h2 className="text-lg font-bold text-white tracking-tight">Dependency Graph</h2>
-        <p className="text-xs text-slate-400 mt-1">
-          Interactive React Flow visualization of memories, derivations, disputes, and supersede relations.
-        </p>
+    <div className="space-y-4 h-[calc(100vh-8rem)] flex flex-col">
+      {/* Header & Controls */}
+      <div
+        className={
+          'flex flex-wrap items-center justify-between gap-4 border-b ' +
+          'border-slate-800 pb-3 shrink-0'
+        }
+      >
+        <div>
+          <div className="flex items-center gap-2">
+            <Share2 className="w-5 h-5 text-indigo-400" />
+            <h2 className="text-lg font-bold text-white tracking-tight">Dependency Graph</h2>
+            {apiNodes.length > 0 && (
+              <span className={badgeClass}>
+                {apiNodes.length} nodes · {apiEdges.length} edges
+              </span>
+            )}
+          </div>
+          <p className="text-xs text-slate-400 mt-1">
+            Interactive React Flow visualization of memories, derivations, disputes, and relations.
+          </p>
+        </div>
+
+        {/* Filters and Actions */}
+        <div className="flex items-center gap-3">
+          <div
+            className={
+              'flex items-center gap-2 bg-slate-900 border border-slate-800 ' +
+              'rounded-lg px-2.5 py-1.5'
+            }
+          >
+            <Filter className="w-3.5 h-3.5 text-slate-400" />
+            <select
+              value={selectedEntity}
+              onChange={(e) => setSelectedEntity(e.target.value)}
+              className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer"
+            >
+              <option value="">All Entities</option>
+              {catalog?.entities?.map((ent, idx) => {
+                const name =
+                  typeof ent.name === 'string'
+                    ? ent.name
+                    : String(ent.name ?? `entity-${idx}`);
+                return (
+                  <option key={name} value={name}>
+                    {name}
+                  </option>
+                );
+              })}
+            </select>
+          </div>
+
+          <button
+            type="button"
+            onClick={() => refetch()}
+            disabled={isFetching}
+            className={refreshBtnClass}
+            title="Refresh graph"
+          >
+            <RefreshCw className={`w-3.5 h-3.5 ${isFetching ? 'animate-spin' : ''}`} />
+            <span>Refresh</span>
+          </button>
+        </div>
+      </div>
+
+      {/* Relationship Type Legend */}
+      <div className={legendClass}>
+        <span className="text-slate-400 font-semibold flex items-center gap-1">
+          <Layers className="w-3.5 h-3.5" />
+          Relations:
+        </span>
+        <div className="flex items-center gap-1.5">
+          <span className="w-2.5 h-2.5 rounded-full bg-purple-400" />
+          <span className="text-slate-300">supersedes</span>
+        </div>
+        <div className="flex items-center gap-1.5">
+          <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
+          <span className="text-slate-300">contradicts</span>
+        </div>
+        <div className="flex items-center gap-1.5">
+          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
+          <span className="text-slate-300">depends_on</span>
+        </div>
+        <div className="flex items-center gap-1.5">
+          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
+          <span className="text-slate-300">refines</span>
+        </div>
+        <div className="flex items-center gap-1.5">
+          <span className="w-2.5 h-2.5 rounded-full bg-slate-500" />
+          <span className="text-slate-400">about</span>
+        </div>
+      </div>
+
+      {/* Main Canvas Area */}
+      <div
+        className={
+          'flex-1 relative rounded-xl border border-slate-800 bg-slate-950 ' +
+          'overflow-hidden flex'
+        }
+      >
+        {isLoading && (
+          <div className="absolute inset-0 z-10 flex items-center justify-center bg-slate-950/80">
+            <LoadingSpinner label="Loading dependency graph..." />
+          </div>
+        )}
+
+        {isError && (
+          <div className="absolute inset-0 z-10 flex items-center justify-center p-6">
+            <ErrorState
+              error={error}
+              title="Failed to load graph"
+              onRetry={() => refetch()}
+            />
+          </div>
+        )}
+
+        {!isLoading && !isError && apiNodes.length === 0 && (
+          <div className="absolute inset-0 z-10 flex items-center justify-center p-6">
+            <EmptyState
+              icon={Share2}
+              title="No Graph Nodes Found"
+              description="Ingest messages to populate entities and memories in the graph."
+            />
+          </div>
+        )}
+
+        {/* React Flow Container */}
+        <div className="flex-1 h-full">
+          <ReactFlow
+            nodes={rfNodes}
+            edges={rfEdges}
+            nodeTypes={nodeTypes}
+            onNodeClick={onNodeClick}
+            fitView
+            minZoom={0.2}
+            maxZoom={1.5}
+            proOptions={{ hideAttribution: true }}
+          >
+            <Background color="#334155" gap={20} size={1} />
+            <Controls
+              className={
+                'bg-slate-900 border border-slate-700 rounded text-slate-200 fill-slate-200'
+              }
+            />
+            <MiniMap
+              nodeColor={(node) => (node.type === 'entity' ? '#6366f1' : '#3b82f6')}
+              className="bg-slate-900 border border-slate-800 rounded-lg"
+              maskColor="rgba(15, 23, 42, 0.7)"
+            />
+          </ReactFlow>
+        </div>
+
+        {/* Node Detail Drawer / Panel */}
+        {selectedNode && (
+          <div className="absolute right-0 top-0 bottom-0 z-20">
+            <GraphDetailPanel
+              node={selectedNode}
+              edges={apiEdges}
+              onClose={() => setSelectedNodeId(null)}
+              onInspectProvenance={(id) => setInspectMemoryId(id)}
+            />
+          </div>
+        )}
       </div>
 
-      <EmptyState
-        icon={Share2}
-        title="Dependency Graph Ready for P9.4"
-        description="Interactive React Flow graph with entity and memory nodes will be integrated in batch P9.4."
+      {/* Provenance Drawer */}
+      <ProvenanceDrawer
+        memoryId={inspectMemoryId}
+        onClose={() => setInspectMemoryId(null)}
       />
     </div>
   );
diff --git a/frontend/src/pages/TimelinePage.tsx b/frontend/src/pages/TimelinePage.tsx
index bc0d7d8..922297a 100644
--- a/frontend/src/pages/TimelinePage.tsx
+++ b/frontend/src/pages/TimelinePage.tsx
@@ -1,21 +1,165 @@
-import React from 'react';
-import { Clock } from 'lucide-react';
+import React, { useState } from 'react';
+import { Clock, RefreshCw, Filter, Layers } from 'lucide-react';
+import { useTimeline, useCatalog } from '../api/hooks';
+import { getTimelineLaneKey } from '../lib/timeline';
+import { TimelineLaneCard } from '../components/timeline/TimelineLaneCard';
+import { ProvenanceDrawer } from '../components/memories/ProvenanceDrawer';
+import { LoadingSpinner } from '../components/common/LoadingSpinner';
+import { ErrorState } from '../components/common/ErrorState';
 import { EmptyState } from '../components/common/EmptyState';
 
 export function TimelinePage(): React.JSX.Element {
+  const [selectedEntity, setSelectedEntity] = useState<string>('');
+  const [selectedAttribute, setSelectedAttribute] = useState<string>('');
+  const [inspectMemoryId, setInspectMemoryId] = useState<number | null>(null);
+
+  const { data: catalog } = useCatalog();
+
+  const queryParams = {
+    entity: selectedEntity || undefined,
+    attribute: selectedAttribute || undefined,
+  };
+
+  const {
+    data: timelines,
+    isLoading,
+    isError,
+    error,
+    refetch,
+    isFetching,
+  } = useTimeline(queryParams);
+
+  const lanes = timelines ?? [];
+
+  const laneBadgeClass =
+    'px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-800 ' +
+    'text-slate-300 border border-slate-700';
+
+  const filterBoxClass =
+    'flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5';
+
+  const refreshBtnClass =
+    'flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 ' +
+    'hover:bg-slate-700 text-slate-200 text-xs font-medium border ' +
+    'border-slate-700 transition-colors cursor-pointer disabled:opacity-50';
+
   return (
     <div className="space-y-6">
-      <div className="border-b border-slate-800 pb-4">
-        <h2 className="text-lg font-bold text-white tracking-tight">Slot Timeline</h2>
-        <p className="text-xs text-slate-400 mt-1">
-          Temporal visualization showing valid intervals, superseding events, and non-overlapping history.
-        </p>
+      {/* Header & Controls */}
+      <div
+        className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4"
+      >
+        <div>
+          <div className="flex items-center gap-2">
+            <Clock className="w-5 h-5 text-indigo-400" />
+            <h2 className="text-lg font-bold text-white tracking-tight">Slot Timeline</h2>
+            {lanes.length > 0 && (
+              <span className={laneBadgeClass}>
+                {lanes.length} {lanes.length === 1 ? 'lane' : 'lanes'}
+              </span>
+            )}
+          </div>
+          <p className="text-xs text-slate-400 mt-1">
+            Temporal visualization of memory lifecycles, validity intervals, and revisions.
+          </p>
+        </div>
+
+        {/* Filter Controls */}
+        <div className="flex flex-wrap items-center gap-3">
+          {/* Entity Filter */}
+          <div className={filterBoxClass}>
+            <Filter className="w-3.5 h-3.5 text-slate-400" />
+            <select
+              value={selectedEntity}
+              onChange={(e) => setSelectedEntity(e.target.value)}
+              className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer"
+            >
+              <option value="">All Entities</option>
+              {catalog?.entities?.map((ent, idx) => {
+                const name =
+                  typeof ent.name === 'string'
+                    ? ent.name
+                    : String(ent.name ?? `entity-${idx}`);
+                return (
+                  <option key={name} value={name}>
+                    {name}
+                  </option>
+                );
+              })}
+            </select>
+          </div>
+
+          {/* Attribute Filter */}
+          <div className={filterBoxClass}>
+            <Layers className="w-3.5 h-3.5 text-slate-400" />
+            <select
+              value={selectedAttribute}
+              onChange={(e) => setSelectedAttribute(e.target.value)}
+              className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer"
+            >
+              <option value="">All Attributes</option>
+              {catalog?.attributes?.map((attr) => (
+                <option key={attr.attribute} value={attr.attribute}>
+                  {attr.attribute}
+                </option>
+              ))}
+            </select>
+          </div>
+
+          {/* Refresh Button */}
+          <button
+            type="button"
+            onClick={() => refetch()}
+            disabled={isFetching}
+            className={refreshBtnClass}
+            title="Refresh timeline"
+          >
+            <RefreshCw className={`w-3.5 h-3.5 ${isFetching ? 'animate-spin' : ''}`} />
+            <span>Refresh</span>
+          </button>
+        </div>
       </div>
 
-      <EmptyState
-        icon={Clock}
-        title="Slot Timeline Ready for P9.4"
-        description="Temporal interval bars and historical state progression will be integrated in batch P9.4."
+      {/* Loading & Error States */}
+      {isLoading && <LoadingSpinner label="Loading slot timelines..." />}
+
+      {isError && (
+        <ErrorState
+          error={error}
+          title="Failed to load timeline"
+          onRetry={() => refetch()}
+        />
+      )}
+
+      {/* Empty State */}
+      {!isLoading && !isError && lanes.length === 0 && (
+        <EmptyState
+          icon={Clock}
+          title="No Timeline Lanes"
+          description="Ingest messages to see temporal slot lanes and historical memory revisions."
+        />
+      )}
+
+      {/* Timeline Lanes List */}
+      {!isLoading && !isError && lanes.length > 0 && (
+        <div className="space-y-6">
+          {lanes.map((lane) => {
+            const laneKey = getTimelineLaneKey(lane);
+            return (
+              <TimelineLaneCard
+                key={laneKey}
+                lane={lane}
+                onSelectMemory={(id) => setInspectMemoryId(id)}
+              />
+            );
+          })}
+        </div>
+      )}
+
+      {/* Provenance Detail Drawer */}
+      <ProvenanceDrawer
+        memoryId={inspectMemoryId}
+        onClose={() => setInspectMemoryId(null)}
       />
     </div>
   );

```
